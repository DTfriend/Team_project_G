<h1>API 사용법</h1>

<br>
http://127.0.0.80/echo_call?dep={출발 공항 코드}&arr={도착 공항 코드}&dep_time={출발 시각(ex:13시면 13으로 입력)}&arr_time={도착 시각(ex:13시면 13으로 입력)}&via={경유 횟수}&total_time={총 소요 시간}&arr_month={출발한 날의 월}&arr_weekend={주말이 얼마나 남았는지, 금요일이면 1}&type={좌석 등급 입력}
